import flet as ft


def main(page: ft.Page):
    page.add(ft.SafeArea(ft.Text("Olá, esse é apenas um teste, ainda! Logo logo o site da Jamago Tech estará disponível")))


ft.app(main)
